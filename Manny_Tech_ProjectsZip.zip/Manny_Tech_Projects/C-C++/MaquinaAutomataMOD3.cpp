/***************************************************
Descripcion:
Programa que modela el automata que como entrada
{0,1,2,3} y como salida suma acumulada mod 3 {0,1,2}
***************************************************/
//LIBRERIAS Y DEFINICIONES DE CONSTANTES
#include <stdio.h>
#include <math.h>
#define FIN_CADENA '\n'

//Modelado de los estados
enum{q0,q1,q2};

//PROGRAMA PRINCIPAL
int main (void)
{
	int estado; 	//Estado Actual 
	char entrada;	//Caracter de entrada
	
	printf("Este programa modela el automata que complementa una secuencia de bits a la entrada {010101} \n"    );
	printf("Introduzca la secuencia de entrada terminando con enter \n"    );
	
	
	do{
		entrada=getchar();	//Leer la primera entrada
	    if(entrada==FIN_CADENA) //FIN_CADENA equivale a un salto de pagina o enter
	       break;
	}while(!(entrada>='0'&&entrada<='1'));
     
	estado=q0; // Estado inicial 	
	
	//Ciclo que modela transicin del automata conforme avanza el cabezal de lectura
	while(entrada!=FIN_CADENA) 	//Mientras la entrada no sea el final de la cadena
	{
		switch(estado)
		{
			case q0: //Modelado de las transiciones del estado q0
				if(entrada=='0'){
					printf("%d",1);
					estado=q0;
				}
				else if(entrada=='1'){
				    printf("%d",0);
				    estado=q0;
					break;					
		}
	}
		entrada=getchar();
		if(entrada==FIN_CADENA)
		   printf(" Salida del Automata " );
		  
	}
	

	return 0; //Fin de programa
}
