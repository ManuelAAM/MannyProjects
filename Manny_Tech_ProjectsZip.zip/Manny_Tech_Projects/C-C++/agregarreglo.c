//meter numeros a las posiciones de un arreglo

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

void funcion(int *vec);
void leer(int *vec);

int main(){
	int vec[10];
	
	funcion(vec);
	leer(vec);

	return 1;
}

void funcion(int *vec){
	int i;
	
	for(i=0;i<10;i++){
		printf("Introduce un valor para la posicion %i: ",i+1);
		scanf("%i",(vec+i));
	}
	
}

void leer(int *vec){
	int i;
	
	for(i=0;i<10;i++){
		printf("%i ",*(vec+i));
 }
}
