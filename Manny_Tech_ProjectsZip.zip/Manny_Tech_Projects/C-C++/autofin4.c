#include <stdio.h>
#include <stdbool.h>
#define FIN_CADENA '\n'

bool reconoce() {
    int estado = 0;
    char entrada;

    // Leer la primera entrada v�lida
    do {
        entrada = getchar();
        if (entrada == FIN_CADENA)
            return false;
    } while (!(entrada == 'a' || entrada == 'b' || entrada == 'z'));

    // Ciclo que modela la transici�n del aut�mata
    while (entrada != FIN_CADENA) {
        switch (estado) {
            case 0:
                if (entrada == 'a') {
                    estado = 1;
                } else {
                    return false;
                }
                break;
            case 1:
                if (entrada == 'b') {
                    estado = 2;
                } else {
                    return false;
                }
                break;
            case 2:
                if (entrada == 'b') {
                    estado = 2;
                } else if (entrada == 'z') {
                    estado = 3;
                } else {
                    return false;
                }
                break;
            case 3:
                if (entrada == 'b') {
                    estado = 4;
                } else {
                    return false;
                }
                break;
            case 4:
                if (entrada == 'b') {
                    estado = 4;
                } else {
                    return false;
                }
                break;
            default:
                return false;
        }
        entrada = getchar();
    }
    return (estado == 2 || estado == 4);
}

int main() {
    printf("Ingrese la cadena: ");
    if (reconoce()) {
        printf("La cadena pertenece al lenguaje.\n");
    } else {
        printf("La cadena NO pertenece al lenguaje.\n");
    }

    return 0;
}

