//desviacionestandar

#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<math.h>
#include<string.h>

int main(){
	int i, j, k, m, n;
	char med[]={};
	float desviacion;
	int **v1;
	int suma;
	printf("Elige la cantidad de numeros: ");
	scanf("%i",&n);
	
	v1 = (int**)malloc(n*sizeof(int*));
	if(v1 == NULL){
		printf("No se ha podido reservar la memoria.");
		exit(1);
	}
	
	srand(time(NULL));
	for(i=0; i < n; i++){
			
		v1 [i] = (int*)malloc(n*sizeof(int));
		if(v1 == NULL){
		printf("No se ha podido reservar la memoria.");
		exit(1);
	}
	else{
		
		v1[i] = rand()%501;
		
		printf("El numero en la posicion %i es: %i\n",i, v1[i]);
		
		suma+=v1[i];

		}
	}
	printf("La suma es: %i\n",suma);
	
	
	
	m=suma/n;
	printf("La media de los numeros es: %i",m);
	
	return 1;
}

