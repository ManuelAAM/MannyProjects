#include <stdio.h>
#include <stdlib.h>
#include <conio.h> //esta libreria no hace nada aqui, no deberias usarla nunca
#include <math.h> //esta tampoco es necesaria, al menos en este caso
#include <time.h>
 
int main()
{
	int a[100];
	int i,dato,elem,promedio,desv,varianza,diferencia,suma; //promedio, suma, varianza y desviacion son datos de coma flotante, debes declararlos como floats
 
	printf("\n Introduce el tama�o del arreglo: ");
	scanf("%d", &dato);
	printf("\n");
 
	for(i=0; i<dato; i++)
	{
		printf(" Introduce los elementos del arreglo: ");
		scanf("%d", &a[i]);
	}
 
	printf("\n\n");
 
	for(i=0; i<dato; i++)
	{
		printf(" %d", a[i]);
	}
 
	for(i=0; i<dato; i++)
	{
		promedio +=(a[i])/(dato); // asi haces tantas divisiones como elementos del vector
	}
 
       //promedio = promedio /dato; si lo pones aqui haces unicamente una division
 
	printf("\n\n El promedio de los elementos es: %d", promedio-1);
 
	//Diferencia de los elementos
	diferencia=diferencia-a[0]; //esto no sirve para nada, ademas no has inicializado diferencia
        //suma = 0 debes acumular los cuadrados de las diferencias, es el sumatorio tipico en la formula
 
	for(i=0; i<dato; i++)
	{
		diferencia=diferencia-a[i]; //aqui deberia ser diferencia = a[i] - promedio, asi restas la media al elemento
                // suma + = diferencia * diferencia y acumulas los cuadrados
	}
	printf("\nLa diferencia es: %d", diferencia); //cuidado en los prints, acuerdate que la mayoiri de tus variables deberian ser numeros de coma flotante
 
	for(i=0; i<dato; i++) //este bucle no tiene sentido
	{
		varianza=(diferencia)*(diferencia)/(dato);
	}
 
       //varianza = suma / dato, o (dato-1) segun si es una muestra o una poblacion
	printf("\n\n La varianza es: %d", varianza);	
}
