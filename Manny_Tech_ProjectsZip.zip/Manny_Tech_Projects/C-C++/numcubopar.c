//cubo de un numero o saber si es par o impar

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main(){
	int numero, opcion;
	float  saldo, retiro, agregar;
	
	printf("Digite la opcion de su preferencia");
	printf("\n1. Elevar mi numero al cubo: ");
	printf("\n2. Saber si mi numero es par o impar: ");
	printf("\n3. Salir");
	printf("\nElija su opcion: ");
	scanf("%i",&opcion);
	
	switch(opcion){
		case 1: 
			printf("Escriba un numero \n");
			scanf("%i",&numero);
			numero=numero*numero*numero;
			printf("\nTu numero al cubo es: %i\n",numero);
			break;
			
		case 2:
			printf("Escriba un numero \n");
			scanf("%i",&numero);
			if(numero%2==0){
				printf("\nTu numero ingresado, %i, es par.\n",numero);
			}
			else
			{
				printf("\nTu numero ingresado, %i, es IMPAR.\n",numero);
			}
			break;
		case 3: 
		break;
		default:
		printf("\nIngrese una opcion valida.\n");		
	}
	
	return 0;
}

