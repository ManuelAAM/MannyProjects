//ordenamiento de vectores menor a mayor

#include <stdio.h>
#include<stdlib.h>
#include<math.h>

void ordenarv(int u[],int x);

int main (){
 	int a; 
 	printf("Cuantos numeros quieres ordenar de menor a mayor?\n");
 	scanf("%i",&a);
 	
 	int v[a];
 	
 	ordenarv(v,a);  

 	return 0;
}

void ordenarv(int u[],int x){
 	int i, j, aux, l, n;
 
 	for (n=0;n<x;n++){
  		printf("Ingresa el %i numero:",n+1);
  		scanf("%i", &u[n]);
  		printf("En el arreglo original la posicion %i tiene al numero %i\n\n",n,u[n]);
 } 
 
 	for (i=0;i<x;i++){  
  		for(j=i;j<x;j++){
   			if(u[i]>u[j]){
    			aux=u[i];
    			u[i]=u[j];
    			u[j]=aux;
   }
  }
 }
 for(l=0;l<x;l++){
  printf("La posicion %i tiene al numero %i\n",l,u[l]);
 }  
}

