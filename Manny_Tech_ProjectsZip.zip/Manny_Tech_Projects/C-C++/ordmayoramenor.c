//ordenamiento de vectores mayor a menor

#include <stdio.h>
#include<stdlib.h>
#include<math.h>

void ordenarv(int u[],int x);

int main (){
 	int a; 
 	printf("Cuantos numeros quieres ordenar de mayor a menor?\n");
 	scanf("%i",&a);
 	
 	int v[a];
 	
 	
 	ordenarv(v,a);  

 	return 0;
}

void ordenarv(int u[],int x){
 	int i, j, aux, l, n;
 	//funcional
 	for (n=0;n<x;n++){
  		printf("Ingresa el %i numero:",n+1);
  		scanf("%i", &u[n]);
  		printf("En el arreglo original la posicion %i tiene al numero %i\n\n",n,u[n]);
 } 
 
 	for (i=0;i<n;i++){
  		for(j=i;j<n;j++){ //{3,8,4,6,9,5,2,1,0,10}
   			if(u[i]<u[j]){
    			aux=u[i];
    			u[i]=u[j];
    			u[j]=aux;
   }
  }
 }
 for(l=0;l<n;l++){
  printf("La posicion %i tiene al numero %i\n",l,u[l]);
 }  
}

/* c�digo unido de maM y de Mam
#include <stdio.h>
void ordenarmaM (int a[]);
void ordenarMam (int A[]);
void imprimirmaM(int x[]);
void imprimirMam(int y[]);
	
int main(){
	
	int v[10] = {10,56,2,34,87,9,53,3,1,6};
	
	ordenarmaM (v);
	imprimirmaM(v);
	
	ordenarMam (v);
	imprimirMam(v);
	
	system("pause");
	return 0;
}

void ordenarmaM (int a[]){
	int i , j, aux ;
	
	for(i = 0; i < 10; i++){
		for(j = 0; j < 10; j++){
			if(a[i] < a[j]){
				aux = a[i];
				a[i] = a[j];
				a[j] = aux;
			}
		}
	}
	
	
}

void imprimirmaM(int x[]){
	int I;
	
	printf("Orden de Menor a Mayor\t");
	for(I = 0; I < 10; I++){
		printf("%d, ", x[I]);
		
	}
	printf("\n\n");
}


void ordenarMam (int A[]){
	int I , J, AUX ;
	
	for(I = 0; I < 10; I++){
		for(J = 0; J < 10; J++){
			if(A[I] > A[J]){
				AUX = A[I];
				A[I] = A[J];
				A[J] = AUX;
			}
		}
	}
	
	
}



void imprimirMam(int y[]){
	int Y;
	
	printf("Orden de Mayor a Menor\t");
	for(Y = 0; Y < 10; Y++){
		printf("%d, ", y[Y]);
		
	}
	printf("\n\n");
}
*/

