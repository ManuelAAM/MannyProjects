//promedio estaturas

#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<string.h>

int main(){
	int i, a;
	float promedio;
	float **lest;
	
	printf("Cuantos numeros quieres guardar?\n");
 	scanf("%i",&a);
	int e[a];

 	estaturas(e,a);  
	
	for(i=0; i < a; i++)	{
		promedio += e[i];
	}
	
	promedio = promedio/a;
	printf("El promedio es: %f",promedio);
	
	return 1;
}

void estaturas(int e[],int a){
 	int n;
 	
 	for (n=0;n<a;n++){
  		printf("Ingresa la %i estatura:",n+1);
  		scanf("%i", &e[n]);
  		printf("En el arreglo original la posicion %i tiene al numero %i\n\n",n,e[n]);
 } 
}

