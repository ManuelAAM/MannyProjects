#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int sub(char *c, int *m, int T, int N);

int main() {
    char word[100];
    
    printf("Ingresa una palabra: ");
    scanf("%s", word);
    
    int mask[100] = {0}; // ARREGLO AJUSTABLE
    int NS;

    NS = sub(word, mask, strlen(word), 0);
    printf("Numero total de subcadenas: %d\n", NS);

    return 0;
}

int sub(char *c, int *m, int T, int N) {
	
    int i, mc[T];
    static int NS = 0;

    if (N == T)
        return 0;

    // Imprimir subcadena
    for (i=0; i<T; i++) {
        if (m[i] == 0 || m[i] == 2) {
            printf("%c", c[i]);
        }
    }
    
    printf("\n");
    NS++;

    memcpy(mc, m, sizeof(int) * T);
    for (i = 0; i < T; i++) {
    	
        if (m[i] == 0) {
        	
            mc[i] = 1;
            sub(c, mc, T, N + 1);
            mc[i] = 2;
        }
    }

    return NS;
}

