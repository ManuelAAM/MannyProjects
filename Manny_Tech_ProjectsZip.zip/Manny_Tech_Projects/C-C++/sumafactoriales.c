//calcule la suma de 2 numeros factoriales dados

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main(){
	int i, j, sumfact=0, factn1=1, factn2=1, n1, n2;
	
	printf("Digite el primer numero a sacar su valor factorial: ");
	scanf("%i",&n1);
	printf("\nDigite el segundo numero a sacar su valor factorial:");
	scanf("%i",&n2);
	
	for(i=1;i<=n1;i++){
			factn1 *= i;
	}
	
	for(j=1;j<=n2;j++){
			factn2 *= j;
		}
		
	sumfact=factn1+factn2;
	printf("\nEl primer numero factorial es: %i",factn1);
	printf("\nEl segundo numero factorial es: %i",factn2);
	printf("\n\nLa suma de los numeros factoriales dados es: %i\n",sumfact);
	return 0;
}

